from group_detection_PRF import *


def run_grpeval(pth):
    """_summary_ run group detection evaluation offline

    Args:
        pth (str): .npy file containing group detection result, you can get it by saving group_detection_result in train_net.py
        group_detection_result = {
        'prediction': [],
        'GT': []}

    Returns:
        list: [Mat.IOU, IOU@AUC, IOU@0.5]
    """
    dicts = np.load(pth, allow_pickle=True)
    grp_result = np.ndarray.tolist(dicts)
    pred = grp_result['prediction']
    gt = grp_result['GT']
    ret_ = []
    ret =  matiou(pred, gt), iouauc(pred, gt), evaluate_group_detection(pred, gt)[-1]
    for i in ret:
        ret_.append(str(round(i*100, 2)))

    return ret_