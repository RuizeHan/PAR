# PAR
Panoramic Human Activity Recognition

We have released the dataset and code to the public.

Dataset Link: https://pan.baidu.com/s/1K8RDNteaphYJY8YEAg5fyA Password: PHAR

More details are coming soon...
